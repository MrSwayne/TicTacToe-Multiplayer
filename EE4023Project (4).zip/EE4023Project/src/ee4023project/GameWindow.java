/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4023project;

import java.awt.event.ActionEvent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author Cailean
 */


public class GameWindow extends javax.swing.JFrame {

    /**
     * Creates new form GameScreen
     */
    private TTTWebService tttProxy;
    private int userID;
    private int gameID;
    private int player1;
    private int xCord= 0; 
    private int yCord = 0;
    private String username;
    private MyButton[][] tiles;
    private JPanel myPanel;
    
    
    
    public GameWindow(int gameID, int userID, String username, int player, MyButton[][] tiles) {
        
        this.gameID = gameID;
        this.userID = userID;
        this.username = username;
        this.player1 = player;
        this.tiles = tiles;
        
        
    }
    
    public void initComponents() {
        
        myPanel = new JPanel();
        JLabel turnLabel = new JLabel();
        
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                xCord = i;
                yCord = j;
                tiles[i][j].addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        tileActionEvent(evt, xCord, yCord);
                    }
                });
            }
        }
    }
    
    public void tileActionEvent(ActionEvent e, int x, int y){
        setButton(x, y);
    }
    
    public void setButton(int x, int y){
        tiles[x][y].setText(player1 + "");
    }
}
