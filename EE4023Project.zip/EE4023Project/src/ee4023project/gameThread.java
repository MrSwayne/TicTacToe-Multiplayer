/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4023project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import ttt.james.server.TTTWebService;
import ttt.james.server.TTTWebService_Service;

/**
 *
 * @author Beans
 */
public class gameThread extends Thread {
    
    private TTTWebService proxy;
    private TTTWebService_Service service;
    public JPanel gamePanel;
    private int interval;
    private boolean myTurn;
    private boolean playing;
    public int pID;
    int gID;
    String XorO;
    public MyButton tiles[][];
    
    public gameThread(int id){
        super();
        System.out.println("Thread initialized");
        pID = id;
        //gamePanel = new JPanel();
        XorO = " ";
        
        service = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        myTurn = false;
        tiles = new MyButton[3][3];
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                MyButton b = new MyButton(i,j);
                //b.addActionListener(this);
                tiles[i][j] = b;
            }
        }
        //tiles = new MyButton[3][3];
    }
    
    public gameThread(int id, int gid, JPanel p, int i, String XorO){
        super();
        service = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        
        this.XorO = XorO;
        myTurn = false;
        playing = true;
        gamePanel = p;
        pID = id;
        interval = i*1000;
        //tiles = updateTiles(gid, XorO);
        tiles = new MyButton[3][3];
        //for(int k=0; k<3; k++){
            //for(int j=0; j<3; j++){
               //MyButton b = new MyButton(k,j);
                //b.addActionListener(new ActionListener() {
                
                /*@Override
                public void actionPerformed(ActionEvent a){
                    System.out.println("touchy");
                    
                    //MyButton b = (MyButton) source;
                    if(myTurn(gID)){
                        if(makeMove(b.getMyX(), b.getMyY(), gID)){
                            //b.setText(XorO);
                            tiles = updateTiles(gID, XorO);
                            String gameState = proxy.checkWin(gID);
                            if(gameState.equals("0")){
                                System.out.println("play on nerds");
                                //playOn = makeRandomMove();
                            }
                            else if(gameState.equals("1")){
                                System.out.println("congrats player 1");
                                proxy.setGameState(gID, 1);
                                playing = false;
                            }
                            else if(gameState.equals("2")){
                                System.out.println("congrats player 2");
                                proxy.setGameState(gID, 2);
                                playing = false;
                            }
                            else if(gameState.equals("3")){
                                System.out.println("is a draw");
                                proxy.setGameState(gID, 3);
                                playing = false;
                            }
                        }
                    }
                }
            });*/
                //tiles[k][j] = b;
                //gamePanel.add(tiles[k][j]);
            //}
        //}
        /*for(int j=0; j<3; j++){
            for(int k=0; k<3; k++){
                gamePanel.add(tiles[j][k]);
            }
        }*/
    }
    
    public void setGameID(int gID){
        this.gID = gID;
    }
    
    public void setXorO(String option){
        XorO = option;
    }
    
    public MyButton[][] getTiles(){
        return tiles;
    }
    
    public boolean myTurn(int gid){
        
        String board = proxy.getBoard(gid);
        String moves[] = board.split("\\n");
        
        String moveBits[] = moves[moves.length-1].split(",");
        
        if(moveBits[0].equals(pID + "")){
            myTurn = false;
        }
        else{
            myTurn = true;
        }
        System.out.println(myTurn);
        return myTurn;
    }
    
    public boolean makeMove(int x, int y, int gid){ //int pid){
        
        String squareAvailable = proxy.checkSquare(x, y, gid);
        boolean take = false;
        if(squareAvailable.equals("1")){
            take = false;
        }
        else if(squareAvailable.equals("0")){
            String takeSquare = proxy.takeSquare(x, y, gid, this.pID);
            if(takeSquare.equals("1")){
                take = true;
            }
            else if(takeSquare.equals("0")){
                take = false;
            }
            System.out.println(takeSquare);
        }
        //System.out.println(takeSquare);
        
        return take;
        
    }
    
    public String joinGame(int gid){
        String result = proxy.joinGame(this.pID, gid);
        return result;
    }
    
    public MyButton[][] updateTiles(int gid, String XorO){
        String other = "";
        /*if(XorO.equals("X")){
            other = "O";
        }
        else{
            other = "X";
        }*/
        //MyButton tempTiles[][] = new MyButton[3][3];
        String board = proxy.getBoard(gid);
        
        String[] boardBits = board.split("\\n");
        if(boardBits.length > 0){
            //String[] bitsBits = boardBits[i].split(",");
            for(int i=0; i<boardBits.length; i++){
                String[] bitsBits = boardBits[i].split(",");
                if(bitsBits.length == 3){
                    //String[] bitsBits = boardBits[i].split(",");
                    int x = Integer.parseInt(bitsBits[1]);
                    int y = Integer.parseInt(bitsBits[2]);
                    if(bitsBits[0].equals(this.pID)){
                        tiles[x][y].setText("X");
                    }
                    else{
                        tiles[x][y].setText("O");
                    }
                }
                
            }
        }
        
        return tiles;
    }
    
    @Override
    public void run(){
        while(playing){
            
            tiles = updateTiles(gID, XorO);
            System.out.println("playing");
            
            try{
                sleep(interval);
            }catch(Exception e){
                
            }
            
        }
    }
    
    
    /*@Override
    public void actionPerformed(ActionEvent a){
        Object source = a.getSource();
        
        if(source instanceof MyButton){
            MyButton b = (MyButton) source;
            if(myTurn(gID)){
                if(makeMove(b.getMyX(), b.getMyY(), gID)){
                    //b.setText(XorO);
                    tiles = updateTiles(gID, XorO);
                    String gameState = proxy.checkWin(gID);
                    if(gameState.equals("0")){
                        System.out.println("play on nerds");
                        //playOn = makeRandomMove();
                    }
                    else if(gameState.equals("1")){
                        System.out.println("congrats player 1");
                        proxy.setGameState(gID, 1);
                        playing = false;
                    }
                    else if(gameState.equals("2")){
                        System.out.println("congrats player 2");
                        proxy.setGameState(gID, 2);
                        playing = false;
                    }
                    else if(gameState.equals("3")){
                        System.out.println("is a draw");
                        proxy.setGameState(gID, 3);
                        playing = false;
                    }
                }
            }
        }
    }*/
    
    public void playerJoined(int gID){
        String game = proxy.showMyOpenGames(this.pID);
        boolean joined = false;
        String []gameParts = game.split("\\n");
        if(gameParts.length > 0){
            for(int i=0; i<gameParts.length; i++){
                String gameDetails[] = gameParts[i].split(",");
                
            }
        }
    }
    
}
