
package ee4023project; //utter mess

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;


import ttt.james.server.TTTWebService_Service;
import ttt.james.server.TTTWebService;


public class TicTacToeClient extends JFrame implements ActionListener {
    
    int GameID;             //id of current game
    int ID;                 //id of logged in user
    int NO_COLS = 4;            //column number in leaderboard table
    String username;        //username of logged in user
    String XorO;
    boolean gameSelected;
    
    private TTTWebService proxy;
    private TTTWebService_Service service;
    
    gameThread thread;
    gameThread p2;
    
    //don't know why this is here
    String wsdl = "";
    
    //private JButton[] moves;
    MyButton[][] buttons; //game tiles
    
    //used for back button
    private JPanel lastPanel;
    
    private JPanel activePanel = null;
    private JPanel gamePanel = null;
    
    private int turn;
    private boolean win;
    
    private JButton loginButton;
    private JButton registerButton;
    private JButton registerOk;
    
    //old
    private JButton yes;
    private JButton no;
    
    //not sure why these are global
    private JTextField Tfirstname;
    private JTextField Tsurname;
    private JTextField Tusername;
    private JTextField Tpassword;
   
    private JTextField pass;
    private JTextField user;        

    public TicTacToeClient(){
        
        service = new TTTWebService_Service();
        proxy = service.getTTTWebServicePort();
        //buttons = new MyButton[3][3];
        
        this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        this.setTitle("TicTacToe :D");
        buttons = new MyButton[3][3];
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                buttons[i][j] = new MyButton(i, j);
            }
        }
        
    }
    
    
    public void run(){
        
        activePanel = showLogin();
        this.add(activePanel);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        //this.pack();    
        this.setSize(300, 200);
    }
    
    public static void main(String[] args) {
        
        TicTacToeClient client = new TicTacToeClient();
        client.run();
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               
            }
        });
    }

    
    public JPanel showLogin() {
        
        JPanel container = new JPanel(new GridLayout(3,0));
        container.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                
        JPanel userPanel = new JPanel();
        user = new JTextField("", 10);
        JLabel userLabel = new JLabel("Username");
        userPanel.add(userLabel);
        userPanel.add(user);
        
        JPanel passPanel = new JPanel();
        pass = new JTextField("", 10);
        JLabel passLabel = new JLabel("Password");
        passPanel.add(passLabel);
        passPanel.add(pass);
        
        
        JPanel controlPanel = new JPanel();
        registerButton = new JButton("Register");
        registerButton.addActionListener(this);
        loginButton = new JButton("Sign in");
        loginButton.addActionListener(this);
        
        controlPanel.add(registerButton);
        
        controlPanel.add(loginButton);
        
        container.add(userPanel);
        container.add(passPanel);
        container.add(controlPanel);
        container.setVisible(true);
        return container;
    }
    

    
    private JPanel showGame(){
        
        //thread = new gameThread(ID);
        
        
        
        JPanel container = new JPanel(new GridLayout(3,3));
      
        JPanel updateHolder = new JPanel();
        
        
        
        win = false;
        //buttons = thread.updateTiles(GameID, XorO);
        
        
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){

                buttons[i][j] = new MyButton(i, j);
                buttons[i][j].addActionListener(this);
                buttons[i][j].setBackground(Color.WHITE);
                
                buttons[i][j].addActionListener(this);
                container.add(buttons[i][j]);
            }
        }
        
        
        container.setVisible(true);

        
        //thread.start();
        
        
        
        return container;
        
    }
     
    
    @Override
    public void actionPerformed(ActionEvent e){
            
        Object source = e.getSource();
        JButton b = (JButton) source;
        
        System.out.println("ID: " + ID);
        System.out.println("usern: " + username);
        String t = b.getText();
        
        
        if(t != null){
            if(source == loginButton){

                ID = proxy.login(user.getText(), pass.getText());
                System.out.println(ID);
                if(ID > 0){
                    username = user.getText();
                    //thread = new gameThread(ID);


                    //this.remove(loginPanel);
                    this.remove(activePanel);
                   //menuPanel = Menu();
                    activePanel = menu();
                    //this.add(menuPanel);
                    this.add(activePanel);
                    this.pack();
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();
                }
                else{

                        lastPanel = showLogin();

                        this.remove(activePanel);
                        activePanel = popUp("Account does not exist.");
                        this.add(activePanel);
                        this.pack();
                        this.setLocationRelativeTo(null);
                        this.validate();
                        this.repaint();

                }

            } 

            else if(source == registerButton){ // wants to register an account, there is no going back.

                    lastPanel = registerScreen();

                    this.remove(activePanel);
                    activePanel = registerScreen();
                    this.add(activePanel);
                    this.pack();
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();

            }

            else if(source == registerOk){ // clicked ok on registry window

                String result = "";
                String message = "";

                //checking fields are not empty
                if(!(Tusername.getText().equals("")) && Tpassword.getText() != null && 
                   Tfirstname.getText() != null && Tsurname.getText()!= null){

                    result = proxy.register(Tusername.getText(), Tpassword.getText(), Tfirstname.getText(), Tsurname.getText());
                    System.out.println("result: " + result);

                    try{
                        ID = Integer.parseInt(result);
                        if(ID > 0){

                            lastPanel = registerScreen();

                            this.remove(activePanel);
                            activePanel = showLogin();
                            this.add(activePanel);
                            this.pack();
                            this.setLocationRelativeTo(null);
                            this.validate();
                            this.repaint();
                        }
                    } catch(Exception ex){

                        if(result.equals("ERROR-REPEAT")){

                            message = "Account already exists.";

                        }
                        else if(result.equals("ERROR-INSERT")){

                            message = "Adding account was unsuccessful.";

                        }
                        else if(result.equals("ERROR-RETRIEVE") || result.equals("ERROR-DB")){
                            message = "Problem with database.";
                        }

                        ID = 0;

                        lastPanel = registerScreen();

                        this.remove(activePanel);
                        activePanel = popUp(message);
                        this.add(activePanel);
                        this.pack();
                        this.setLocationRelativeTo(null);
                        this.validate();
                        this.repaint();

                    }
                }
                else{ // fields were empty
                    lastPanel = registerScreen();

                    this.remove(activePanel);
                    activePanel = popUp("All fields must be full.");
                    this.add(activePanel);
                    this.pack();
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();
                }

            }

            else if(b.getText().equals("Score")){ // show score window

                this.remove(activePanel);
                activePanel = scoreScreen();
                this.add(activePanel);
                this.pack();
                this.setLocationRelativeTo(null);
                this.validate();
                this.repaint();

            }

            else if(b.getText().equals("Leader Board")){

                this.remove(activePanel);
                activePanel = leaderBoardScreen();
                this.add(activePanel);
                this.pack();
                this.setLocationRelativeTo(null);
                this.validate();
                this.repaint();
            }

            else if(b.getText().equals("Create Game")){

                String tempID = proxy.newGame(ID);
                try{
                    GameID = Integer.parseInt(tempID);

                    gamePanel = new JPanel();

                    //thread = new gameThread(ID, GameID, gamePanel, 3, "X");
                    //buttons = thread.updateTiles(GameID, XorO);
                    gamePanel = showGame();
                    thread = new gameThread(ID, GameID, gamePanel, 3, "X");
                    //hread.setXorO("X");
                    this.remove(activePanel);
                    this.add(gamePanel);

                    thread.start();

                    this.setSize(600, 600);
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();


                }
                catch(NumberFormatException ex){
                    lastPanel = menu();
                    this.remove(activePanel);
                    activePanel = popUp("Game could not be created.");
                    this.add(activePanel);
                    this.pack();
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();

                }
                System.out.println(tempID);

            }

            else if(b.getText().equals("Join Game")){
                if(gameSelected){
                    //XorO = "O";
                    thread.joinGame(GameID);
                    System.out.println("Game id in join game button thing: " + GameID);
                    this.remove(activePanel);
                    activePanel = showGame();
                    this.add(activePanel);
                    this.setSize(600, 600);
                    this.setLocationRelativeTo(null);
                    this.validate();
                    this.repaint();
                }
            }

            else if(b instanceof MyButton){
                //XorY = "X";
                MyButton bx = (MyButton) b;
                boolean turn = thread.myTurn(GameID);
                boolean playOn = true;
                //String gameState = proxy.checkWin(GameID);
                System.out.println("buttons pressed");
                if(turn){
                    if(thread.makeMove(bx.getMyX(), bx.getMyY(), GameID)){//, ID)){
                        b.setText(XorO);
                        String gameState = proxy.checkWin(GameID);

                        if(gameState.equals("0")){
                            System.out.println("play on nerds");
                            //playOn = makeRandomMove();
                        }
                        else if(gameState.equals("1")){
                            System.out.println("congrats player 1");
                            proxy.setGameState(GameID, 1);
                            
                        }
                        else if(gameState.equals("2")){
                            System.out.println("congrats player 2");
                            proxy.setGameState(GameID, 2);
                            
                        }
                        else if(gameState.equals("3")){
                            System.out.println("is a draw");
                            proxy.setGameState(GameID, 3);
                            
                        }
                    }
                }

                //playOn = makeRandomMove();
            }
                /*String gameThing = proxy.checkWin(GameID);

                if(gameThing.equals("0")){
                    System.out.println("play on nerds");
                    if(turn){
                        if(thread.makeMove(bx.getMyX(), bx.getMyY(), GameID)){//, ID)){
                            b.setText(XorY);
                        }
                    }
                    makeRandomMove();
                }
                else if(gameThing.equals("1")){
                        System.out.println("congrats player 1");
                        thread.stop();
                        p2.stop();
                }
                else if(gameThing.equals("2")){
                        System.out.println("congrats player 2");
                        thread.stop();
                        p2.stop();
                }
                else if(gameThing.equals("3")){
                        System.out.println("is a draw");
                       thread.stop();
                       p2.stop();
                }
    */


            else if(b.getText().equals("Clear")){ // clear registration fields

                Tfirstname.setText("");;
                Tsurname.setText("");
                Tusername.setText("");
                Tpassword.setText("");

            }

            else if(b.getText().equals("Okay")){ // close message window
                System.out.println("Okay");

                //this.remove(messagePanel);
                this.remove(activePanel);
                //registerPanel = RegisterScreen();
                activePanel = lastPanel;
                this.add(activePanel);
                this.pack();
                this.validate();
                this.repaint();
            }

            else if(b.getText().equals("Back")){

                this.remove(activePanel);
                activePanel = menu();
                this.add(activePanel);
                this.pack();
                this.validate();
                this.repaint();
            }

            else if(b.getText().equals("Log Out")){

                this.remove(activePanel);
                activePanel = showLogin();
                this.add(activePanel);
                this.pack();
                this.validate();
                this.repaint();

                ID = 0;
            }
        }
    }
    
    
    private JPanel menu(){
        JPanel container = null;
        container = new JPanel(new GridLayout(0,1, 30, 30));
        container.setBorder(BorderFactory.createEmptyBorder(40, 40, 0, 40));
        JPanel panel = new JPanel();
        
        
        Component c;
        String games = proxy.showOpenGames();
        if(games.equals("ERROR-NOGAMES")){
            c = new JLabel("No games to display.");
        }
        else if(games.equals("ERROR-NODB")){
            c = new JLabel("Problems connecting to database.");
        }
        else{
            JTable t = getOpenGames();
            t.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
            
                @Override
                public void valueChanged(ListSelectionEvent event) {

                    GameID = Integer.parseInt(t.getValueAt(t.getSelectedRow(), 0).toString());
                    gameSelected = true;
                } 

            });
            c = new JScrollPane(t);
        
            Dimension d = t.getPreferredSize();
            c.setPreferredSize(
                new Dimension(d.width,t.getRowHeight()*5+40));   
        }
        
        JLabel lab = new JLabel("To join a game, select one from the list \nand click 'Join Game'.");
        
        JButton score = new JButton("Score");
        score.addActionListener(this);
        
        JButton leaderBoard = new JButton("Leader Board");
        leaderBoard.addActionListener(this);
        
        JButton createGame = new JButton("Create Game");
        createGame.addActionListener(this);
        
        JButton logOut = new JButton("Log Out");
        logOut.addActionListener(this);
        
        JButton joinThisGame = new JButton("Join Game");
        joinThisGame.addActionListener(this);
        
        container.add(lab);
        container.add(c);
        panel.add(score);
        panel.add(leaderBoard);
        panel.add(createGame);
        panel.add(logOut);
        panel.add(joinThisGame);
        container.add(panel);
        
        return container;
        
        //a table of open games 
        
        
        //a mechanism to join one of the games 
        
        
    }
    
   
    
    private JPanel scoreScreen(){
        
        JPanel container = null;
        container = new JPanel(new GridLayout(0, 2, 20, 20));
        container.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        
        JButton back = new JButton("Back");
        back.addActionListener(this);
        
        String s = getScores(username);
        System.out.println("scores: " + s);
        JLabel w;
        JLabel l;
        JLabel d;
        if(!(s.equals("ID_VOID"))){
            String []sBits = s.split(",");
            
            w = new JLabel(sBits[1] + "");
            l = new JLabel(sBits[2] + ""); 
            d = new JLabel(sBits[3] + ""); 
        }
        else{
            w = new JLabel("0");
            l = new JLabel("0"); 
            d = new JLabel("0"); 
        }
        
        
        
        JLabel won = new JLabel("Wins:");
        JLabel lost = new JLabel("Losses:");
        JLabel drew = new JLabel("Draws:");
        
        /*JLabel w = new JLabel(sBits[1] + "");
        JLabel l = new JLabel(sBits[2] + ""); 
        JLabel d = new JLabel(sBits[3] + ""); */
        
            
        container.add(won);
        container.add(w,0,1);
        container.add(lost);
        container.add(l);
        container.add(drew);
        container.add(d);
        container.add(back);

        return container;
        
    }
    
    private JPanel leaderBoardScreen(){
        
        JPanel container = null;
        container = new JPanel(new GridLayout(0, 1, 40, 40));
        container.setBorder(BorderFactory.createEmptyBorder(40, 40, 0, 40));
        JButton back =  new JButton("Back");
        back.addActionListener(this);
        
        JPanel buttonHolder = new JPanel();
        buttonHolder.add(back);
        
        
        //String games = proxy.leagueTable();
        //String gameRows[] = games.split("\\n");

        String[] columns = new String[] {"Username", "Wins", "Losses", "Draws"};
        String s = "";

        String users = getRegisteredUsers();
        String usernames[] = users.split(",");
        
        String data[][] = new String[usernames.length][NO_COLS];

        for(int i=0; i<usernames.length; i++){
            
            s = getScores(usernames[i]);
            String scoreParts[] = s.split(",");
            for(int j=0; j<scoreParts.length; j++){
                data[i][j] = scoreParts[j];
            }
        }

        JTable table = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);
        
        Dimension d = table.getPreferredSize();
        scrollPane.setPreferredSize(
            new Dimension(d.width,table.getRowHeight()*usernames.length+40));
        
        
        //JPanel scrollPane = new JPanel();
        //scrollPane.add(table);
        container.add(scrollPane);
        container.add(buttonHolder);
        
        return container;
    }
    
    private JPanel registerScreen(){

        //JPanel container = null;
        JPanel container = new JPanel(new GridLayout(0,1));
        JPanel bits = new JPanel(new GridLayout(5, 0, 15, 15));
        bits.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JButton clear = new JButton("Clear");
        clear.addActionListener(this);
        registerOk = new JButton("Ok");
        registerOk.addActionListener(this);
        //JButton goBack = new JButton("Back");
        //registerOk.addActionListener(this);
        
        JLabel firstname = new JLabel("Firstname");
        JLabel surname = new JLabel("Surname");
        JLabel username = new JLabel("Username");
        JLabel password = new JLabel("Password");
        
        Tfirstname = new JTextField("", 10);
        Tsurname = new JTextField("", 10);
        Tusername = new JTextField("", 10);
        Tpassword = new JTextField("", 10);
        
        bits.add(firstname);
        bits.add(Tfirstname, 0, 1);
        bits.add(surname);
        bits.add(Tsurname);
        bits.add(username);
        bits.add(Tusername);
        bits.add(password);
        bits.add(Tpassword);
        
        
        bits.add(clear);
        bits.add(registerOk);
        
        container.add(bits);
        
        return container;
    }
    
    public JPanel popUp(String msg){
        
        JPanel mesagePanel = null;
        JPanel messagePanel = new JPanel(new GridLayout(0, 1, 20, 20));
        messagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel message = new JLabel(msg);
        
        messagePanel.add(message);
        JButton okay = new JButton("Okay");
        okay.addActionListener(this);
        okay.setPreferredSize(new Dimension(15, 20));
        
        messagePanel.add(okay);
        
        return messagePanel;
        
    }
    
    private String getScores(String username){
        
        String result = "ID_VOID";
        
        int winCount = 0;
        int lossCount = 0;
        int drawCount = 0;

        int px = 0;
        int Npx = 0;
        String leagueTable = proxy.leagueTable();
        System.out.println(leagueTable);
        String tableRows[] = leagueTable.trim().split("\\n");
        

        if(tableRows.length > 1){
            for(int i=0; i < tableRows.length; i++){

                String rowParts[] = tableRows[i].split(",");
                if(rowParts[1].equals(username)){
                    px = 1;
                    Npx = 2;
                }
                else if(rowParts[2].equals(username)){
                    px = 2;
                    Npx = 1;
                }

                int gameState = Integer.parseInt(rowParts[3]);

                if(px != 0){ 

                    if(rowParts[px].equals(username) && gameState == px){

                        winCount++;
                    }
                    else if(rowParts[px].equals(username) && gameState == Npx){

                        lossCount++;
                    }
                    else if(gameState == 3){

                        drawCount++;
                    }

                }

                px = 0;
                Npx = 0;

            }
            result = username + "," + winCount + "," + lossCount + "," + drawCount;
            
        }
        else{
            
        }

        return result;
    }
    
    private String getRegisteredUsers(){
        String result = "";
        
        String leagueTable = proxy.leagueTable();
        String leagueBits[] = leagueTable.split("\\n");
        
        ArrayList<String> players = new ArrayList<String>();
        
        if(leagueBits.length > 1){
        for(int i=0; i<leagueBits.length; i++){
            String[] gameBits = leagueBits[i].split(",");
            if(!(players.contains(gameBits[1]))){
                players.add(gameBits[1]);
            }
            if(!(players.contains(gameBits[2]))){
                players.add(gameBits[2]);
            }
        }
        
        for(int i=0; i<players.size(); i++){
            if(i == players.size()-1){
                result += players.get(i);
            }
            else{
                result += players.get(i) + ",";
            }
        }
        }
        
        System.out.println(result);
        
        return result;
    }
    
    
    private JTable getOpenGames(){
        JTable t;
        String openGames = proxy.showOpenGames();
        String gameBits[] = openGames.split("\\n");
        
        String[] columns = new String[] {"Game no.", "Game Creator"};
        String [][]data = new String[gameBits.length][columns.length];
        
        if(openGames.equals("ERROR-NOGAMES")){
            
        }
        else if(openGames.equals("ERROR-DB")){
            
        }
        else{
            for(int i=0; i<gameBits.length; i++){
                String bitsBits[] = gameBits[i].split(",");
                //if(!(bitsBits[1].equals(username))){
                    for(int j=0; j<columns.length; j++){
                        data[i][j] = bitsBits[j];
                    }
                //}
            }
        }
        //gameSelected = false;
        t = new JTable(data, columns);
        
        
        return t;
    }
    
    
    private void clearButtons(){
		
            for(int i=0; i<3; i++){// clear all 9 buttons
                for(int j=0; j<3; j++){
                    buttons[i][j].setText(" ");
                }							
            }
            turn=0; // reset the count

    }
    
    private boolean makeRandomMove(){
        boolean playOn = true;
        if(p2.myTurn(GameID)){
            int r1 = (int)(Math.random() * ((2) + 1));
            int r2 = (int)(Math.random() * ((2) + 1));
            boolean help = p2.makeMove(r1, r2, GameID);
            while(!(help)){
                r1 = (int)(Math.random() * ((2) + 1));
                r2 = (int)(Math.random() * ((2) + 1));
                help = p2.makeMove(r1, r2, GameID);
            }
            String thing = "";
            if(XorO.equals("X")){
                thing = "O";
            }
            else{
                thing = "X";
            }
            buttons[r1][r2].setText(thing);
            buttons = p2.updateTiles(p2.pID, thing);
            String winner = proxy.checkWin(GameID);
            //boolean playOn = true;
            if(!(winner.equals(0))){
                playOn = false;
            }
            //return playOn;
        }
        return playOn;
    }
}